mjpg-streamer output plugin: output_viewer
==========================================

This is a simple plugin that will display the input plugin stream in an SDL
window.

You must have libsdl-devel installed (or similar) in order for this plugin to
be compiled & installed.

Usage
=====

    mjpg_streamer [input plugin options] -o 'output_viewer.so'